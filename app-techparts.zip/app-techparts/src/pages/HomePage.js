import React from 'react';
import { View, Text } from 'react-native';

const HomePage = () => {

  return (

    <View>
    
      <Text> cadelona veia </Text>

    </View>

  );

}

export default HomePage;